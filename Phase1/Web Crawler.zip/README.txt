Java Version: 1.8.0_25

Operating System : Windows 8.1

-------------------------------------------------------------------------------

The script is called crawler.bat. The script compiles and executes the
crawler. Make sure you have MyThread.java, Tuple.java, crawler.java, and
RobotExclusionUtil.java in your directory.

How to run it:

	crawler <seed.txt> <number of pages> <hops Away> <directory>

Type this in the terminal (cmd prompt on windows). This executes the
crawler.bat script.	

-------------------------------------------------------------------------------

If the previous command does not work, use the following command in this order and
have the required files:

	javac *.java
	java crawler <seed.txt> <number of pages> <hops away> <directory>

The first command compiles the .java files together. The second command
executes the crawler.class.

--------------------------------------------------------------------------------


	
